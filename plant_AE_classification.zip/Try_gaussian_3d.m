m = [8 0 8];
s = 1000;
n = bsxfun(@plus,m,s.*randn(100,3));
figure;
plot3(n(:,1),n(:,2),n(:,3),'.r')
M = mean(n,1);
S = std(n,1);