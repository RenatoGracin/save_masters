clear all
load('test_block.mat','data','prevCluster','prevClust_ind','clusterIndices','reachDistList','orderedList','clust_ellipsoids_final');

file_name = 'D:\clusts.bin';
% fileID_h = fopen(file_name,'r');
% read_feats = fopen(fileID_h,400,'float32');
% fclose(fileID_h);

fileID_read = fopen(file_name,'r');
cluster = 0;
clusters = [];
while(~isempty(cluster))
    cluster = fread(fileID_read,8,'float32');
    clusters = [clusters;cluster'];
end
fclose(fileID_read);


file_name = 'D:\peaks.bin';
% fileID_h = fopen(file_name,'r');
% read_feats = fopen(fileID_h,400,'float32');
% fclose(fileID_h);

fileID_read = fopen(file_name,'r');

peak_amp = 0;
step = 0;
while (~isempty(peak_amp))
    clearvars -except fileID_read step peak_amp2 prev_labels_ind
    load(['test_block_' num2str(step) '.mat']);
    peak_amp = fread(fileID_read,400,'float32');
    if isempty(peak_amp)
        break;
    end
    disp(['STEP: ' num2str(step)])

    if step > 0
        disp('check prev indices stayed : ');
        disp(sum(peak_amp2((prev_labels_ind+1))-peak_amp(301:400)));
    end

    reach_dist = fread(fileID_read,400,'float32');
    order_list = fread(fileID_read,400,'uint16');
    labels = fread(fileID_read,400,'uint16');
    prev_labels_ind = fread(fileID_read,100,'uint16');
    local_labels = fread(fileID_read,400,'uint16');

    disp('diff in amp data: ');
    disp(sum(abs(data(:,2)-peak_amp)));
    
    disp('diff in reach dist: ');
    disp(sum(abs(reachDistList-reach_dist)));
    find_reach = find(abs(reachDistList-reach_dist)>0.0001);
    diff_reach = [reachDistList,reach_dist];
    
    disp('diff in order list: ');
    disp(sum(abs(orderedList-(order_list+1))));
    find_order = find(abs(orderedList-(order_list+1))>0);
    diff_order = [orderedList,order_list+1];

    disp('diff in labels: ');
    disp(sum(abs(clusterIndices-(labels))));
    lab_diff = [clusterIndices,labels];

    disp('diff in prev indices: ');
    disp(sum(abs(prevClust_ind'-(prev_labels_ind+1))))
    prev_diff = [prevClust_ind',prev_labels_ind+1];

     disp('diff in local cluster ind: ');
    disp(sum(abs(local_clusterIndices-local_labels)))
    lab_diff_local = [local_clusterIndices,local_labels];

    peak_amp2 = peak_amp;
    step = step +1;
end

fclose(fileID_read);



disp('done');