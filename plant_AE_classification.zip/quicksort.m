function [number,neighIndices] = quicksort(number,first,last,neighIndices)
    if(first<last)
      pivot=first;
      i=first;
      j=last;
    
      while(i<j)
         while(number(i)<=number(pivot)&&i<last)
            i = i +1;
         end
         while(number(j)>number(pivot))
            j = j -1;
         end
         if(i<j)
            temp=number(i);
            mem=neighIndices(i);
			         
            number(i)=number(j);
            neighIndices(i)=neighIndices(j);
			         
            number(j)=temp;
	        neighIndices(j)=mem;
         end
      end
    
      temp=number(pivot);
      mem=neighIndices(pivot);
	        
      number(pivot)=number(j);
	        neighIndices(pivot)=neighIndices(j);
	        
      number(j)=temp;
	        neighIndices(j)=mem;
	        
      [number,neighIndices] = quicksort(number,first,j-1,neighIndices);
      [number,neighIndices] = quicksort(number,j+1,last,neighIndices);
    end
end